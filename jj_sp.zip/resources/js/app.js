require('./bootstrap');

windows.Swal = require('sweetalert2')

