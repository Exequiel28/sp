<div class="footer-left">
    Desarrollado por Estudiantes de ULS &copy; {{ date('Y') }}
</div>
