<?php $__env->startSection('content'); ?>


            <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert">
                    <i class="fa fa-times"></i>
                </button>
            <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
            
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Inicio</h3>
        </div>
        <div class="section-body">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-diseño')): ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                    <div>
                    <br><h5 class="text-center">Sección de Pedidos</h5>
                    </div>
                        <div class="card-body">                       
                            <div class="row">
                                
                                    <div class="col-md-12 col-xl-3">
                                        <div class="card bg-c-pedido order-card">
                                            <div class="card-block">
                                                <h5>Total de Pedidos</h5>   
                                                <?php endif; ?>                                            
                                                <?php
                                                 use App\Models\Pedido;
                                                $cant_pedido = Pedido::count();                                                
                                                ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-diseño')): ?>
                                                <h2 class="text-right"><i class="fas fa-shopping-cart f-left"></i><span><?php echo e($cant_pedido); ?></span></h2>
                                                <p class="m-b-0 text-right"><a href="/pedidos" class="text-white">Ver más</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12 col-xl-3">
                                        <div class="card bg-c-green order-card">
                                            <div class="card-block">
                                                <h5>Pedidos Pendientes</h5>                                               
                                                
                                                <h2 class="text-right"><i class="fas fa-shopping-cart f-left"></i><span><?php echo e($countpen); ?></span></h2>
                                                <p class="m-b-0 text-right"><a href="<?php echo e(route('pedidos.pendientes')); ?>" class="text-white">Ver más</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-xl-3">
                                        <div class="card bg-c-pink order-card">
                                            <div class="card-block">
                                                <h5>Pedidos Terminados</h5>                                               
                                                
                                                <h2 class="text-right"><i class="fas fa-shopping-cart f-left"></i><span><?php echo e($countter); ?></span></h2>
                                                <p class="m-b-0 text-right"><a href="<?php echo e(route('pedidos.terminados')); ?>" class="text-white">Ver más</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-xl-3">
                                        <div class="card bg-c-black order-card">
                                            <div class="card-block">
                                                <h5>Pedidos Entregados</h5>                                               
                                                
                                                <h2 class="text-right"><i class="fas fa-shopping-cart f-left"></i><span><?php echo e($countent); ?></span></h2>
                                                <p class="m-b-0 text-right"><a href="<?php echo e(route('pedidos.entregados')); ?>" class="text-white">Ver más</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                    <div>
                    <br><h5 class="text-center">Sección de Ordenes</h5>
                    </div>
                        <div class="card-body">                       
                            
                                <div class="row">

                                     <div class="col-md-12 col-xl-4">
                                        <div class="card bg-c-pedido order-card">
                                            <div class="card-block">
                                                <h5>Ordenes en Diseño</h5>                                               
                                                
                                                <h2 class="text-right"><i class="fas fa-shopping-cart f-left"></i><span><?php echo e($countdis); ?></span></h2>
                                                <p class="m-b-0 text-right"><a href="<?php echo e(route('ordenes.ordendis')); ?>" class="text-white">Ver más</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-xl-4">
                                        <div class="card bg-c-green order-card">
                                            <div class="card-block">
                                                <h5>Ordenes en Impresion</h5>                                               
                                                
                                                <h2 class="text-right"><i class="fas fa-shopping-cart f-left"></i><span><?php echo e($countimp); ?></span></h2>
                                                <p class="m-b-0 text-right"><a href="<?php echo e(route('ordenes.ordenimp')); ?>" class="text-white">Ver más</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-xl-4">
                                        <div class="card bg-c-pink order-card">
                                            <div class="card-block">
                                                <h5>Ordenes en Acabado</h5>                                               
                                                
                                                <h2 class="text-right"><i class="fas fa-shopping-cart f-left"></i><span><?php echo e($countaca); ?></span></h2>
                                                <p class="m-b-0 text-right"><a href="<?php echo e(route('ordenes.ordenaca')); ?>" class="text-white">Ver más</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                    </div>
                                    </div>
                                    </div>
                                    </div>


            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">                       
                            
                                <div class="row">
                                

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                    <div class="col-md-4 col-xl-4">
                                    
                                    <div class="card bg-c-blue order-card">
                                            <div class="card-block">
                                            <h5>Usuarios</h5>         
                                <?php endif; ?>                                      
                                                <?php
                                                 use App\Models\User;
                                                $cant_usuarios = User::count();                                                
                                                ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                                <h2 class="text-right"><i class="fa fa-users f-left"></i><span><?php echo e($cant_usuarios); ?></span></h2>
                                                <p class="m-b-0 text-right"><a href="/usuarios" class="text-white">Ver más</a></p>
                                            </div>                                            
                                        </div>                                    
                                    </div>
                                 
                                    <div class="col-md-4 col-xl-4">
                                        <div class="card bg-c-green order-card">
                                            <div class="card-block">
                                            <h5>Roles</h5>   
                                <?php endif; ?>                                             
                                                <?php
                                                use Spatie\Permission\Models\Role;
                                                 $cant_roles = Role::count();                                                
                                                ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>                
                                                <h2 class="text-right"><i class="fa fa-user-lock f-left"></i><span><?php echo e($cant_roles); ?></span></h2>
                                                <p class="m-b-0 text-right"><a href="/roles" class="text-white">Ver más</a></p>
                                            </div>
                                        </div>
                                    </div>                                                                
                                <?php endif; ?>    
                                    <div class="col-md-4 col-xl-4">
                                        <div class="card bg-c-pink order-card">
                                            <div class="card-block">
                                                <h5>Inventario</h5>                                               
                                                <?php
                                                 use App\Models\Inventario;
                                                $cant_inventario = Inventario::count();                                                
                                                ?>
                                                <h2 class="text-right"><i class="fas fa-archive f-left"></i><span><?php echo e($cant_inventario); ?></span></h2>
                                                <p class="m-b-0 text-right"><a href="/inventario" class="text-white">Ver más</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xl-4">
                                        <div class="card bg-c-green order-card">
                                            <div class="card-block">
                                                <h5>Clientes</h5>                                               
                                                <?php
                                                 use App\Models\Cliente;
                                                $cant_cliente = Cliente::count();                                                
                                                ?>
                                                <h2 class="text-right"><i class="fas fa-archive f-left"></i><span><?php echo e($cant_cliente); ?></span></h2>
                                                <p class="m-b-0 text-right"><a href="/clientes" class="text-white">Ver más</a></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-xl-4">
                                        <div class="card bg-c-blue order-card">
                                            <div class="card-block">
                                                <h5>Productos</h5>                                               
                                                <?php
                                                 use App\Models\Producto;
                                                $cant_producto = Producto::count();                                                
                                                ?>
                                                <h2 class="text-right"><i class="fas fa-archive f-left"></i><span><?php echo e($cant_producto); ?></span></h2>
                                                <p class="m-b-0 text-right"><a href="/productos" class="text-white">Ver más</a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jj_sp\resources\views/home.blade.php ENDPATH**/ ?>