

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Pedidos Entregados</h3>
        </div>
        <div class="section-body">
        
            <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert">
                    <i class="fa fa-times"></i>
                </button>
            <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>

            
                
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
        


                        
                        

                            <table class="table table-striped mt-2">
                                <thead style="background-color:#009bdb">                                                       
                                    
                                    
                                    <th style="color:#fff;">No</th>
                                    <th style="color:#fff;">Cliente</th>
                                    <th style="color:#fff;">Descripcion</th>
                                    <th style="color:#fff;">Estado</th>
                                    <th style="color:#fff;">Acciones</th>
                                </thead>  
                                <tbody>
                                <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                                
                                <tr>                           
                                
                                
                                    <td><?php echo e($pedido->id); ?></td>
                                    <td><?php echo e($pedido->clientes->nombre); ?></td>
                                    <td><?php echo e($pedido->descripcion); ?></td>
                                    <td>
                                        <a class="jsgrid-button btn btn-primary"
                                            href="">
                                            Entregados 
                                        </a>
                                    </td>
                        
                                
        
                                    

                                   
                                                                    
                                
                                    <td>                                
                                        
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-pedidos')): ?>
                                            
                                            <a href="<?php echo e(route('pedidos.show',$pedido->id)); ?>" title="Ver Pedido"><i class="viewcolor fas fa-eye"></i></a>
                                            
                                        <?php endif; ?>
                                    
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-pedidos')): ?>
                                        
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['pedidos.destroy', $pedido->id],'style'=>'display:inline']); ?>

                                            <?php echo Form::submit('Borrar', ['class' => 'btn btn-sm btn-danger']); ?>

                                            
                                        <?php echo Form::close(); ?>

                                        
                                    <?php endif; ?>  



                                    </td>
                                </tr>
                              
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                                </tbody>               
                            </table>

                            <!-- Centramos la paginacion a la derecha -->
                            <div class="pagination justify-content-end">
                            <?php echo $pedidos->links(); ?> 
                            </div>                    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jj_sp\resources\views/pedidos/entregados.blade.php ENDPATH**/ ?>