<div class="footer-left">
    Desarrollado por Estudiantes de ULS &copy; <?php echo e(date('Y')); ?>

</div>
<?php /**PATH C:\xampp\htdocs\jj_sp\resources\views/layouts/footer.blade.php ENDPATH**/ ?>