

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Facturacion</h3>
        </div>
        <div class="section-body">
        
            <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert">
                    <i class="fa fa-times"></i>
                </button>
            <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>

                 
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
        
                        

                            <!-- Centramos la paginacion a la derecha -->
                            <div class="pagination justify-content-end">
                                
                            </div>                    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jj_sp\resources\views/facturacion/index.blade.php ENDPATH**/ ?>