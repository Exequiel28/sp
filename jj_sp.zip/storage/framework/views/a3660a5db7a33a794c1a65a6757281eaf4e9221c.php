    

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Informacion de la Orden</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">     
                                                                      
                        <?php if($errors->any()): ?>                                                
                            <div class="alert alert-dark alert-dismissible fade show" role="alert">
                            <strong>¡Revise los campos!</strong>                        
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                    
                                    <span class="badge badge-danger"><?php echo e($error); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
                        <?php endif; ?>

                    
                        <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            
                            <div class="col-xs-12 col-sm-12 col-md-8">
                                <div class="form-group"> 
                                   <label for="producto">Producto</label>
                                   <br>
                                   <div class="infoc">
                                       <?php echo e($ordenes->producto); ?>

                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-4">
                                <div class="form-group">
                                   <label for="copias">Copias</label>
                                   <div class="infoc">
                                   <?php echo e($ordenes->copias); ?>

                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-6">
                                <div class="form-group">
                                   <label for="ancho">Ancho</label>
                                   <div class="infoc">
                                   <?php echo e($ordenes->ancho); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6">
                                <div class="form-group">
                                   <label for="alto">Alto</label>
                                   <div class=" infoc">
                                   <?php echo e($ordenes->alto); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-4">
                                <div class="form-group">
                                   <label for="fecha_entrega">Fecha de Entrega</label>
                                   
                                   <div class="infoc">
                                   <?php echo e($ordenes->fecha_entrega); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-4">
                                <div class="form-group">
                                   <label for="hora_entrega">Hora de Entrega</label>
                                   
                                   <div class="infoc">
                                   <?php echo e($ordenes->hora_entrega); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-4">
                                <div class="form-group">
                                   <label for="userventa">Diseñador</label>
                                   <div class="infoc">
                                   <?php echo e($ordenes->userventa); ?>

</div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                   <label for="nit">Descripcion</label>
                                   <div class="infoc">
                                   <?php echo e($ordenes->descripcion); ?>

                                </div>
                            </div>
                            </div>
</div>
                            </div>
                            <a class="btn btn-warning" href="<?php echo e(URL::previous()); ?>">--Volver--</a>
                                                      
                        </div>
                    </form>
                    
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jj_sp\resources\views/ordenes/show.blade.php ENDPATH**/ ?>