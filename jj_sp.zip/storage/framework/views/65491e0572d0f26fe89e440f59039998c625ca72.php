

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Pedidos</h3>
        </div>
        <div class="section-body">
        
            <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert">
                    <i class="fa fa-times"></i>
                </button>
            <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-pedidos')): ?>
            
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-4">
                    <div class="card">
                        <a class="btn btn-warning" href="<?php echo e(route('pedidos.pendientes')); ?>">Pedidos Pendientes</a>                        
                    </div> 
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-4">
                    <div class="card">
                        <a class="btn btn-success" href="<?php echo e(route('pedidos.terminados')); ?>">Pedidos Terminados</a>                        
                    </div> 
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-4">
                    <div class="card">
                        <a class="btn btn-info" href="<?php echo e(route('pedidos.entregados')); ?>">Pedidos Entregados</a>                        
                    </div> 
                </div> 
            </div> 

           
        <?php endif; ?>

            <form  method="get"> 
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" name="texto" placeholder="Buscar">
                        <button class="btn btn-outline-primary" type="submit" id="texto">Buscar</button>
                    </div>
                 </form>
            
                
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-pedidos')): ?>
                        <a class="btn btn-warning" href="">Nuevo</a>                        
                        <?php endif; ?>

                        
                        

                            <table class="table table-striped mt-2">
                                <thead style="background-color:#009bdb">                                                       
                                    
                                    
                                    <th style="color:#fff;">No</th>
                                    <th style="color:#fff;">Cliente</th>
                                    <th style="color:#fff;">Descripcion</th>
                                    <th style="color:#fff;">Estado</th>
                                    <th style="color:#fff;">Acciones</th>
                                </thead>  
                                <tbody>
                                <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>                           
                                
                                
                                    <td><?php echo e($pedido->id); ?></td>
                                    <td><?php echo e($pedido->clientes->nombre); ?></td>
                                    <td><?php echo e($pedido->descripcion); ?></td>
                                    <?php if($pedido->estado == '1'): ?>
                                <td>
                                    <a class="jsgrid-button btn btn-warning"
                                    href="">
                                        En Proceso 
                                    </a>
                                </td>
                            <?php else: ?>
                                <?php if($pedido->estado == '2'): ?>
                                <td>
                                    <a class="jsgrid-button btn btn-success"
                                    href="">
                                        Terminado 
                                    </a>
                                </td>
                                <?php else: ?>
                                <td>
                                    <a class="jsgrid-button btn btn-info"
                                    href="">
                                        Entregado 
                                    </a>
                                </td>
                                <?php endif; ?>
                            <?php endif; ?>
                                    

                                   
                                                                    
                                
                                    <td>                                
                                        
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-pedidos')): ?>
                                            
                                            <a href="<?php echo e(route('pedidos.show',$pedido->id)); ?>" title="Ver Informacion"><i class="viewcolor fas fa-eye"></i></a>
                                            
                                    <?php endif; ?>
                                    
                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-pedidos')): ?>
                                    <?php if($pedido->estado == '2'): ?>      
                                    <a href="<?php echo e(route('pedidos.cestado',$pedido->id)); ?>" title=""><i class="viewcolor fas fa-sign-out-alt"></i></a>
                                    <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-facturacion')): ?>
                                            
                                            <a href="<?php echo e(route('facturacion.index2',$pedido->id)); ?>" title="Facturar">F</a>
                                            
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-pedidos')): ?>
                                        
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['pedidos.destroy', $pedido->id],'style'=>'display:inline']); ?>

                                            <?php echo Form::submit('Borrar', ['class' => 'btn btn-sm btn-danger']); ?>

                                            
                                        <?php echo Form::close(); ?>

                                        
                                    <?php endif; ?>   



                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>               
                            </table>

                            <!-- Centramos la paginacion a la derecha -->
                            <div class="pagination justify-content-end">
                            <?php echo $pedidos->appends(['texto'=>$texto]); ?> 
                            </div>                    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </section>
        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jj_sp\resources\views/pedidos/index.blade.php ENDPATH**/ ?>