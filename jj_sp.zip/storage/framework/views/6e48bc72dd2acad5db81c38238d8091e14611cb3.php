

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Modificar Orden</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">     
                                                                      
                        <?php if($errors->any()): ?>                                                
                            <div class="alert alert-dark alert-dismissible fade show" role="alert">
                            <strong>¡Revise los campos!</strong>                        
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                    
                                    <span class="badge badge-danger"><?php echo e($error); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
                        <?php endif; ?>

                    
                        <form action="<?php echo e(route('ordenes.update',$ordenes->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                   <label for="producto">Producto</label>
                                   <select name="producto" class="form-select custom-select" aria-label="Default select example">
                                   <?php $__currentLoopData = $lista_productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->nombre); ?>"><?php echo e($item->nombre); ?></option>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-4">
                                <div class="form-group">
                                    <label for="unidadm">Unidad de Medida</label>
                                    <select class="form-select custom-select" aria-label="Default select example" id="unidadm" name="unidadm">
                                    
                                    <option selected disabled>Seleccione Unidad</option>
                                    <option value="1">Centimetros</option>
                                    <option value="2">Metros</option>
                                    <option value="3">Pulgadas</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-4">
                                <div class="form-group">
                                   <label for="ancho">Ancho</label>
                                   <input type="number" step=".01" name="ancho" class="form-control" value="<?php echo e($ordenes->ancho); ?>">
                                </div>
                            </div>                            
                            <div class="col-xs-12 col-sm-12 col-md-4">
                                <div class="form-group">
                                   <label for="alto">Alto</label>
                                   <input type="number" step=".01" name="alto" class="form-control" value="<?php echo e($ordenes->alto); ?>">
                                </div>
                            </div>
                            
                            <div class="col-xs-12 col-sm-12 col-md-6">
                                <div class="form-group">
                                   <label for="fecha_entrega">Fecha de Entrega</label>
                                   <input type="date" id="fecha_entrega" name="fecha_entrega" class="form-control" value="<?php echo e($ordenes->fecha_entrega); ?>">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-6">
                                <div class="form-group">
                                   <label for="hora_entrega">Hora de Entrega</label>
                                   <input type="time" id="hora_entrega" name="hora_entrega" class="form-control" value="<?php echo e($ordenes->hora_entrega); ?>">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6">
                                <div class="form-group">
                                   <label for="precio">Precio</label>
                                   <input type="number" step=".01" name="precio" class="form-control" value="<?php echo e($ordenes->precio); ?>">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6">
                                <div class="form-group">
                                   <label for="preciodis">Precio de Diseño</label>
                                   <input type="number" step=".01" name="preciodis" class="form-control" value="<?php echo e($ordenes->preciodis); ?>"> 
                                   <input type="hidden" name="userventa" class="form-control" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?>">
                                   <input type="hidden" name="id_pedido" class="form-control" value="<?php echo e($ordenes->id_pedido); ?>">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                   <label for="descripcion">Descripcion</label>
                                   <textarea type="text" id="descripcion" name="descripcion" class="form-control"><?php echo e($ordenes->descripcion); ?></textarea>
                                </div>
                            </div>
                                                       
                        </div>
                        <button type="submit" class="btn btn-primary">Guardar</button> 

                    </form>
                    
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jj_sp\resources\views/ordenes/edit.blade.php ENDPATH**/ ?>