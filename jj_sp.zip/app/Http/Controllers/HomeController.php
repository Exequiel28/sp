<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

use App\Models\Inventario;
use App\Models\Useinventario;
use App\Models\Producto;
use App\Models\Cliente;
use App\Models\Pedido;
use App\Models\Orden;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Arr;
use PDF;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {

        $countpen = Pedido::where('estado','=','1')->count();

        $countter = Pedido::where('estado','=','2')->count();

        $countent = Pedido::where('estado','=','3')->count();

        $countdis = Orden::where('estado','=','1')->count();

        $countimp = Orden::where('estado','=','2')->count();

        $countaca = Orden::where('estado','=','3')->count();

        $data =[
            'countpen'=>$countpen,
            'countter'=>$countter,
            'countent'=>$countent,
            'countdis'=>$countdis,
            'countimp'=>$countimp,
            'countaca'=>$countaca,
        ]    ;  

        return view('home',$data);
    }

public function reportes(Request $request){
    // $countprod = Orden::select('producto')->count();
    //$ordenes = DB::table('ordenes')->select('producto')->groupBy('producto')->count('*') ;
    //$ordenes = Orden::all('*');
    // $ordenes = Orden::whereBetween('created_at', [$fecha1, $fecha2])->get();
    //  return view('reportes.index');
    $fecha1 = $request->get('fecha1');
    $fecha2 = $request->get('fecha2');

    $ordenes = Orden::whereBetween('fecha_entrega', [$fecha1, $fecha2])->get();

    $fecha3 = $request->get('fecha3');
    $fecha4 = $request->get('fecha4');

 //SELECT SUM(`total`) FROM `ordenes` WHERE `fecha_entrega` >= '2022-09-29' AND `fecha_entrega`<'2022-10-28'

 //$ordenestotal = DB::table('ordenes')->select('total')->sum('total')->whereBetween('fecha_entrega', [$fecha3, $fecha4])

 $ordenestotal = DB::table('ordenes')->select('total')->whereBetween('fecha_entrega', [$fecha3, $fecha4])->sum('total');

 $fecha5 = $request->get('fecha5');
 $fecha6 = $request->get('fecha6');

 $ordenesprod = DB::table('ordenes')
                ->select('producto',DB::raw('COUNT(*) as venta'))
                ->whereBetween('fecha_entrega', [$fecha5, $fecha6])
                ->groupBy('producto')
                ->get();;
 
 //dd($ordenesprod);
 
 
        

       
       
 
 return view('reportes.index', compact('ordenes','ordenestotal','ordenesprod'));
        
    

}

public function downloadPDF($ordenesprod)
    {
        view()->share('reportes.productos',$ordenesprod);
        $pdf = PDF::loadView('reportes.productos', ['ordenesprod' => $ordenesprod]);
        return $pdf->download('Productos.pdf');
    }





public function consulta(Request $request){


    // $countprod = Orden::select('producto')->count();
 
    
 
     //$ordenes = DB::table('ordenes')->select('producto')->groupBy('producto')->count('*') ;
 //$ordenes = Orden::all('*');
    $fecha1 = $request->get('fecha1');
    $fecha2 = $request->get('fecha2');
 
 
    $ordenes = Orden::whereBetween('fecha_entrega', [$fecha1, $fecha2])
 ->get();
     return view('reportes.index', compact('ordenes'));
 
 
 
 
 }

}
